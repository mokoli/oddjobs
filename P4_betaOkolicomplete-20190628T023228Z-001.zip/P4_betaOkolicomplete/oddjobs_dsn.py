DSN = {'user':'oddjobs',
       'passwd':'35YBOs94pjaKXAU', ## find in .my.cnf
       'host':'localhost'
       }
